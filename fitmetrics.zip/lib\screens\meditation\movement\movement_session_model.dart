import 'package:flutter/material.dart';

/// Data model for a single movement meditation session.
/// Add new sessions by adding to [movementSessions] list only —
/// no other files need changing.
class MovementSession {
  final String id;
  final String title;
  final String imagePath;
  final IconData icon;
  final List<Color> gradientColors;
  final Color accentColor;
  final List<String> bulletPoints;
  final String duration;
  final String difficulty;

  const MovementSession({
    required this.id,
    required this.title,
    required this.imagePath,
    required this.icon,
    required this.gradientColors,
    required this.accentColor,
    required this.bulletPoints,
    required this.duration,
    required this.difficulty,
  });
}

// ── Image base path ────────────────────────────────────────────────────────────
// All images live in: assets/images/meditation/movement/
// Add new images there and reference them using _img() below.

String _img(String name) =>
    'assets/images/meditation/movement/$name';

// ── All sessions ───────────────────────────────────────────────────────────────
// To add a new session: add a new MovementSession entry here. That's it.

const List<MovementSession> movementSessions = [
  MovementSession(
    id: 'walking_turtle',
    title: 'Walking Turtle',
    imagePath: 'assets/images/meditation/movement/walking_turtle.jpg',
    icon: Icons.directions_walk,
    gradientColors: [Color(0xFF1A3A2A), Color(0xFF0F1F16)],
    accentColor: Color(0xFF4CAF50),
    duration: '10 min',
    difficulty: 'Beginner',
    bulletPoints: [
      'Move slowly and breathe deeply with each step',
      'Grounds your mind in the present moment',
      'Perfect for releasing built-up tension',
    ],
  ),
  MovementSession(
    id: 'the_fountain',
    title: 'The Fountain',
    imagePath: 'assets/images/meditation/movement/the_fountain.jpg',
    icon: Icons.water,
    gradientColors: [Color(0xFF0D2137), Color(0xFF0A1520)],
    accentColor: Color(0xFF29B6F6),
    duration: '12 min',
    difficulty: 'Beginner',
    bulletPoints: [
      'Flow through gentle rising and falling movements',
      'Clears mental fog and restores calm energy',
      'Inspired by the natural rhythm of water',
    ],
  ),
  MovementSession(
    id: 'rising_tide',
    title: 'Rising Tide',
    imagePath: 'assets/images/meditation/movement/rising_tide.jpg',
    icon: Icons.waves,
    gradientColors: [Color(0xFF0A2340), Color(0xFF061525)],
    accentColor: Color(0xFF1E88E5),
    duration: '15 min',
    difficulty: 'Intermediate',
    bulletPoints: [
      'Build strength through steady rising movements',
      'Awakens confidence and inner resilience',
      'Let each breath lift you higher',
    ],
  ),
  MovementSession(
    id: 'flowing_water',
    title: 'Flowing Water',
    imagePath: 'assets/images/meditation/movement/flowing_water.jpg',
    icon: Icons.stream,
    gradientColors: [Color(0xFF0D2B3E), Color(0xFF091A26)],
    accentColor: Color(0xFF26C6DA),
    duration: '14 min',
    difficulty: 'Beginner',
    bulletPoints: [
      'Fluid movements that follow your breath',
      'Releases stiffness and restores flexibility',
      'Feel yourself flow with effortless grace',
    ],
  ),
  MovementSession(
    id: 'falling_rain',
    title: 'Falling Rain',
    imagePath: 'assets/images/meditation/movement/falling_rain.jpg',
    icon: Icons.grain,
    gradientColors: [Color(0xFF1A2535), Color(0xFF0F1825)],
    accentColor: Color(0xFF7986CB),
    duration: '10 min',
    difficulty: 'Beginner',
    bulletPoints: [
      'Calm yourself with falling rain meditation',
      'Feel relief and complete ease in each breath',
      'Let go — breathe in, breathe out',
    ],
  ),
  MovementSession(
    id: 'gentle_breeze',
    title: 'Gentle Breeze',
    imagePath: 'assets/images/meditation/movement/gentle_breeze.jpg',
    icon: Icons.air,
    gradientColors: [Color(0xFF1A2E1F), Color(0xFF0F1D13)],
    accentColor: Color(0xFF66BB6A),
    duration: '8 min',
    difficulty: 'Beginner',
    bulletPoints: [
      'Light swaying movements like leaves in the wind',
      'Soothes anxiety and quiets a busy mind',
      'The gentlest way to begin your practice',
    ],
  ),
  MovementSession(
    id: 'cresting_waves',
    title: 'Cresting Waves',
    imagePath: 'assets/images/meditation/movement/cresting_waves.jpg',
    icon: Icons.waves_outlined,
    gradientColors: [Color(0xFF0D2040), Color(0xFF081428)],
    accentColor: Color(0xFF42A5F5),
    duration: '18 min',
    difficulty: 'Advanced',
    bulletPoints: [
      'Dynamic movements that build and release tension',
      'Deepens body awareness and full presence',
      'Ride the wave of each breath to its peak',
    ],
  ),
];
