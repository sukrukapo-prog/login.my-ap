import 'package:flutter/material.dart';
import 'package:fitmetrics/core/audio_service.dart';
import 'package:fitmetrics/screens/meditation/movement/movement_session_model.dart';
import 'package:fitmetrics/screens/meditation/movement/widgets/movement_card.dart';

/// Movement Meditation screen.
/// Opens when user taps "Movement Meditation" on the meditation home screen.
///
/// Extend this later by:
/// - Adding a MovementPlayerScreen and navigating on onStart
/// - Adding filters (Beginner / Intermediate / Advanced)
/// - Adding a favourites/saved sessions feature
class MovementMeditationScreen extends StatefulWidget {
  const MovementMeditationScreen({super.key});

  @override
  State<MovementMeditationScreen> createState() =>
      _MovementMeditationScreenState();
}

class _MovementMeditationScreenState extends State<MovementMeditationScreen> {
  int? _expandedIndex;

  @override
  void initState() {
    super.initState();
    AudioService().pauseMusic();
  }

  @override
  void dispose() {
    AudioService().resumeMusic();
    super.dispose();
  }

  void _onStart(MovementSession session) {
    AudioService().playClickSound();
    // TODO: Replace with navigation to MovementPlayerScreen when built:
    // Navigator.push(context, MaterialPageRoute(
    //   builder: (_) => MovementPlayerScreen(session: session),
    // ));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Starting ${session.title}...'),
        backgroundColor: session.accentColor.withAlpha(230),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: const EdgeInsets.fromLTRB(24, 0, 24, 80),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F1624),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _Header(onBack: () {
              AudioService().playClickSound();
              Navigator.pop(context);
            }),
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(20, 4, 20, 40),
                itemCount: movementSessions.length,
                separatorBuilder: (_, __) => const SizedBox(height: 14),
                itemBuilder: (context, index) {
                  final session = movementSessions[index];
                  return MovementCard(
                    session: session,
                    isExpanded: _expandedIndex == index,
                    onTap: () => setState(() {
                      _expandedIndex = _expandedIndex == index ? null : index;
                    }),
                    onStart: () => _onStart(session),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Header ─────────────────────────────────────────────────────────────────────

class _Header extends StatelessWidget {
  final VoidCallback onBack;
  const _Header({required this.onBack});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Green chevron back button — matches screenshot
          GestureDetector(
            onTap: onBack,
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: const Color(0xFF22C55E).withAlpha(25),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: const Color(0xFF22C55E).withAlpha(80),
                  width: 1,
                ),
              ),
              child: const Icon(
                Icons.chevron_left,
                color: Color(0xFF22C55E),
                size: 26,
              ),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Movement Meditation',
            style: TextStyle(
              color: Colors.white,
              fontSize: 26,
              fontWeight: FontWeight.w800,
              height: 1.1,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Awaken Your Body & Mind',
            style: TextStyle(
              color: Colors.white54,
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }
}
