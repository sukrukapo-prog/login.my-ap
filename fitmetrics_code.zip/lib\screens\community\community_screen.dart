import 'dart:async';
import 'dart:developer' as developer;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fitmetrics/services/auth_service.dart';
import 'package:fitmetrics/services/local_storage.dart';
import 'package:fitmetrics/services/notification_service.dart';
import 'package:fitmetrics/core/avatar_data.dart';
import 'package:fitmetrics/core/haptic_service.dart';
import 'package:fitmetrics/screens/profile/achievements_screen.dart'
    show allAchievements, Achievement;

// ── Model ──────────────────────────────────────────────────────────────────────

class CommunityMessage {
  final String id;
  final String uid;
  final String displayName;
  final String? avatarId;
  final String text;
  final DateTime timestamp;
  final Map<String, List<String>> reactions;
  final List<_UnlockedBadge> badges;
  final int totalMinutes;
  final bool isDeleted;

  CommunityMessage({
    required this.id,
    required this.uid,
    required this.displayName,
    this.avatarId,
    required this.text,
    required this.timestamp,
    required this.reactions,
    required this.badges,
    this.totalMinutes = 0,
    this.isDeleted = false,
  });

  factory CommunityMessage.fromDoc(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    final rawReactions = (d['reactions'] as Map<String, dynamic>?) ?? {};
    final reactions = rawReactions.map(
          (k, v) => MapEntry(k, List<String>.from(v as List)),
    );
    final rawBadges = (d['badges'] as List?) ?? [];
    final badges = rawBadges
        .map((b) => _UnlockedBadge(
      id: b['id'] as String,
      emoji: b['emoji'] as String,
      title: b['title'] as String,
    ))
        .toList();
    return CommunityMessage(
      id: doc.id,
      uid: d['uid'] as String? ?? '',
      displayName: d['displayName'] as String? ?? 'User',
      avatarId: d['avatarId'] as String?,
      text: d['text'] as String? ?? '',
      timestamp: (d['timestamp'] as Timestamp?)?.toDate() ?? DateTime.now(),
      reactions: reactions,
      badges: badges,
      totalMinutes: (d['totalMinutes'] as int?) ?? 0,
      isDeleted: (d['deleted'] as bool?) ?? false,
    );
  }
}

class _UnlockedBadge {
  final String id;
  final String emoji;
  final String title;
  const _UnlockedBadge({required this.id, required this.emoji, required this.title});
}

// ── Screen ─────────────────────────────────────────────────────────────────────

class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});

  @override
  State<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen>
    with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  final _db = FirebaseFirestore.instance;
  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final _focusNode = FocusNode();

  String? _myUid;
  String _myName = 'User';
  String? _myAvatarId;
  List<_UnlockedBadge> _myBadges = [];
  int _myTotalMinutes = 0;
  bool _sending = false;
  final _showEmojiBar = ValueNotifier<bool>(false);

  // Mention autocomplete
  List<_UserHint> _allUsers = [];
  List<_UserHint> _mentionSuggestions = [];
  String? _mentionQuery; // non-null when actively typing @...
  StreamSubscription? _notifSub;

  static const _quickEmojis = ['🔥', '💪', '🧘', '❤️', '👏', '✨', '😄', '🎉'];
  static const _reactEmojis = ['🔥', '💪', '❤️', '👏', '✨', '😄'];

  @override
  void initState() {
    super.initState();
    _loadMe();
    _loadUsers();
    _msgCtrl.addListener(_onTextChanged);
  }

  @override
  void dispose() {
    _msgCtrl.removeListener(_onTextChanged);
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    _focusNode.dispose();
    _showEmojiBar.dispose();
    _notifSub?.cancel();
    super.dispose();
  }

  Future<void> _loadMe() async {
    final user = await AuthService.getCurrentUser();
    final uid = AuthService.currentFirebaseUser?.uid;
    final avatarId = await LocalStorage.getAvatarId();
    final stats = await LocalStorage.getAllTimeStats();

    // Collect unlocked achievement badges
    final sessions = stats['totalSessions'] ?? 0;
    final streak = stats['streakDays'] ?? 0;
    final minutes = stats['totalMinutes'] ?? 0;

    final badges = <_UnlockedBadge>[];
    for (final a in allAchievements) {
      bool unlocked = false;
      switch (a.category) {
        case 'session':
          unlocked = a.id == 'first_login' ? true : sessions >= a.requiredValue;
          break;
        case 'streak':
          unlocked = streak >= a.requiredValue;
          break;
        case 'time':
          unlocked = minutes >= a.requiredValue;
          break;
      }
      if (unlocked) {
        badges.add(_UnlockedBadge(id: a.id, emoji: a.emoji, title: a.title));
      }
    }

    if (!mounted) return;
    setState(() {
      _myUid = uid;
      _myName = user?.name ?? user?.fullName ?? 'User';
      _myAvatarId = avatarId ?? user?.avatarId;
      _myBadges = badges;
      _myTotalMinutes = stats['totalMinutes'] ?? 0;
    });
    // Reload users without self, then start notification listener
    await _loadUsers();
    _listenForMentions();
  }

  Future<void> _loadUsers() async {
    try {
      final snap = await _db.collection('users').get();
      final users = snap.docs
          .where((d) => d.id != _myUid)
          .map((d) => _UserHint(
        uid: d.id,
        name: (d.data()['name'] as String?)?.isNotEmpty == true
            ? d.data()['name'] as String
            : (d.data()['email'] as String?)?.split('@').first ?? 'User',
        avatarId: d.data()['avatarId'] as String?,
      ))
          .toList();
      if (mounted) setState(() => _allUsers = users);
    } catch (e) {
      developer.log('[Community] loadUsers error: $e');
    }
  }

  void _onTextChanged() {
    final text = _msgCtrl.text;
    final cursor = _msgCtrl.selection.baseOffset;
    if (cursor < 0) return;

    // Find the last @ before cursor
    final before = text.substring(0, cursor);
    final atIndex = before.lastIndexOf('@');

    if (atIndex == -1) {
      if (_mentionQuery != null) setState(() { _mentionQuery = null; _mentionSuggestions = []; });
      return;
    }

    // Make sure there's no space between @ and cursor (active mention)
    final query = before.substring(atIndex + 1);
    if (query.contains(' ')) {
      if (_mentionQuery != null) setState(() { _mentionQuery = null; _mentionSuggestions = []; });
      return;
    }

    final filtered = _allUsers
        .where((u) => u.name.toLowerCase().startsWith(query.toLowerCase()))
        .take(5)
        .toList();

    setState(() {
      _mentionQuery = query;
      _mentionSuggestions = filtered;
    });
  }

  void _selectMention(_UserHint user) {
    HapticService.light();
    final text = _msgCtrl.text;
    final cursor = _msgCtrl.selection.baseOffset;
    final before = text.substring(0, cursor);
    final atIndex = before.lastIndexOf('@');
    final after = text.substring(cursor);

    final newText = '${text.substring(0, atIndex)}@${user.name} $after';
    _msgCtrl.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: atIndex + user.name.length + 2),
    );
    setState(() { _mentionQuery = null; _mentionSuggestions = []; });
  }

  List<String> _extractMentionedUids(String text) {
    final uids = <String>[];
    for (final user in _allUsers) {
      if (text.contains('@${user.name}')) uids.add(user.uid);
    }
    return uids;
  }

  void _listenForMentions() {
    if (_myUid == null) return;
    _notifSub?.cancel();
    _notifSub = _db
        .collection('users')
        .doc(_myUid)
        .collection('notifications')
        .where('read', isEqualTo: false)
        .orderBy('timestamp', descending: true)
        .limit(1)
        .snapshots()
        .listen((snap) {
      for (final doc in snap.docs) {
        final d = doc.data();
        if (d['type'] == 'mention' && mounted) {
          NotificationService.showInAppBanner(
            context: context,
            senderName: d['senderName'] as String? ?? 'Someone',
            messageText: d['messageText'] as String? ?? '',
          );
          // Mark as read
          doc.reference.update({'read': true});
        }
      }
    });
  }

  Future<void> _send() async {
    final text = _msgCtrl.text.trim();
    if (text.isEmpty || _myUid == null || _sending) return;

    setState(() => _sending = true);
    _msgCtrl.clear();
    _showEmojiBar.value = false;
    setState(() { _mentionQuery = null; _mentionSuggestions = []; });

    try {
      final docRef = await _db.collection('community_messages').add({
        'uid': _myUid,
        'displayName': _myName,
        'avatarId': _myAvatarId,
        'text': text,
        'timestamp': FieldValue.serverTimestamp(),
        'reactions': {},
        'totalMinutes': _myTotalMinutes,
        'badges': _myBadges
            .take(3)
            .map((b) => {'id': b.id, 'emoji': b.emoji, 'title': b.title})
            .toList(),
      });

      // Send mention notifications
      final mentionedUids = _extractMentionedUids(text);
      for (final uid in mentionedUids) {
        if (uid != _myUid) {
          await NotificationService.sendMentionNotification(
            mentionedUid: uid,
            senderName: _myName,
            messageText: text,
            messageId: docRef.id,
          );
        }
      }

      // Scroll to bottom after send
      await Future.delayed(const Duration(milliseconds: 200));
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    } catch (e) {
      developer.log('[Community] send error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to send. Check your connection.')),
        );
      }
    } finally {
      if (mounted) setState(() => _sending = false);
    }
  }

  Future<void> _deleteMessage(String messageId) async {
    try {
      await _db.collection('community_messages').doc(messageId).update({
        'deleted': true,
        'text': '',
      });
      HapticService.medium();
    } catch (e) {
      developer.log('[Community] delete error: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not delete message.')),
        );
      }
    }
  }

  Future<void> _react(String messageId, String emoji, Map<String, List<String>> reactions) async {
    if (_myUid == null) return;
    HapticService.medium();

    final existing = reactions[emoji] ?? [];
    final alreadyReacted = existing.contains(_myUid);

    try {
      final ref = _db.collection('community_messages').doc(messageId);
      if (alreadyReacted) {
        await ref.update({
          'reactions.$emoji': FieldValue.arrayRemove([_myUid]),
        });
      } else {
        await ref.update({
          'reactions.$emoji': FieldValue.arrayUnion([_myUid]),
        });
      }
    } catch (e) {
      developer.log('[Community] react error: $e');
    }
  }

  void _insertEmoji(String emoji) {
    HapticService.light();
    final cur = _msgCtrl.text;
    final sel = _msgCtrl.selection;
    final newText = cur.replaceRange(
      sel.start < 0 ? cur.length : sel.start,
      sel.end < 0 ? cur.length : sel.end,
      emoji,
    );
    _msgCtrl.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(
          offset: (sel.start < 0 ? cur.length : sel.start) + emoji.length),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      backgroundColor: const Color(0xFF0F1624),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            Expanded(child: _buildMessageList()),
            ValueListenableBuilder<bool>(
              valueListenable: _showEmojiBar,
              builder: (_, show, __) => Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (_mentionSuggestions.isNotEmpty) _buildMentionSuggestions(),
                  if (show) _buildQuickEmojiBar(),
                  _buildInputBar(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 18, 20, 14),
      decoration: BoxDecoration(
        color: const Color(0xFF0F1624),
        border: Border(bottom: BorderSide(color: Colors.white.withAlpha(15))),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF3B82F6), Color(0xFF8B5CF6)],
              ),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.people_alt_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Community',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w800)),
                Text('Chat with your fitness family',
                    style: TextStyle(color: Colors.white38, fontSize: 12)),
              ],
            ),
          ),
          // Online indicator
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: const Color(0xFF10B981).withAlpha(25),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: const Color(0xFF10B981).withAlpha(60)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(
                    color: Color(0xFF10B981),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 5),
                const Text('Live',
                    style: TextStyle(
                        color: Color(0xFF10B981),
                        fontSize: 11,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageList() {
    return StreamBuilder<QuerySnapshot>(
      stream: _db
          .collection('community_messages')
          .orderBy('timestamp', descending: false)
          .limitToLast(100)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(color: Color(0xFF3B82F6)),
          );
        }

        if (snapshot.hasError) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.wifi_off_rounded, color: Colors.white24, size: 48),
                const SizedBox(height: 12),
                Text('Could not load messages',
                    style: TextStyle(color: Colors.white.withAlpha(80), fontSize: 14)),
              ],
            ),
          );
        }

        final docs = snapshot.data?.docs ?? [];
        if (docs.isEmpty) {
          return _buildEmptyState();
        }

        final messages = docs.map((d) => CommunityMessage.fromDoc(d)).toList();

        // Auto-scroll to bottom when new messages arrive
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_scrollCtrl.hasClients) {
            final max = _scrollCtrl.position.maxScrollExtent;
            final cur = _scrollCtrl.offset;
            // Only auto-scroll if already near bottom (within 200px)
            if (max - cur < 200) {
              _scrollCtrl.animateTo(max,
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOut);
            }
          }
        });

        return GestureDetector(
          onTap: () {
            _focusNode.unfocus();
            _showEmojiBar.value = false;
          },
          child: ListView.builder(
            controller: _scrollCtrl,
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            itemCount: messages.length,
            itemBuilder: (_, i) {
              final msg = messages[i];
              final isMe = msg.uid == _myUid;
              final showDate = i == 0 ||
                  !_isSameDay(messages[i - 1].timestamp, msg.timestamp);
              final showAvatar = !isMe &&
                  (i == messages.length - 1 ||
                      messages[i + 1].uid != msg.uid ||
                      _showDate(messages, i));

              return Column(
                children: [
                  if (showDate) _DateDivider(msg.timestamp),
                  _MessageBubble(
                    key: ValueKey(msg.id),
                    message: msg,
                    isMe: isMe,
                    showAvatar: showAvatar,
                    myUid: _myUid ?? '',
                    onReact: (emoji) => _react(msg.id, emoji, msg.reactions),
                    onDelete: () => _deleteMessage(msg.id),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  bool _showDate(List<CommunityMessage> msgs, int i) {
    if (i + 1 >= msgs.length) return false;
    return !_isSameDay(msgs[i].timestamp, msgs[i + 1].timestamp);
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('🌟', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 16),
          const Text('Be the first to say hello!',
              style: TextStyle(
                  color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text('Share your progress with the community',
              style: TextStyle(color: Colors.white.withAlpha(100), fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildMentionSuggestions() {
    return Container(
      constraints: const BoxConstraints(maxHeight: 200),
      decoration: BoxDecoration(
        color: const Color(0xFF1A2540),
        border: Border(
          top: BorderSide(color: Colors.white.withAlpha(15)),
          bottom: BorderSide(color: Colors.white.withAlpha(15)),
        ),
      ),
      child: ListView.builder(
        shrinkWrap: true,
        padding: const EdgeInsets.symmetric(vertical: 4),
        itemCount: _mentionSuggestions.length,
        itemBuilder: (_, i) {
          final user = _mentionSuggestions[i];
          return GestureDetector(
            onTap: () => _selectMention(user),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  AvatarWidget(avatarId: user.avatarId, size: 32),
                  const SizedBox(width: 12),
                  Text('@${user.name}',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildQuickEmojiBar() {
    return Container(
      height: 52,
      color: const Color(0xFF1A2540),
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        children: _quickEmojis.map((e) {
          return GestureDetector(
            onTap: () => _insertEmoji(e),
            child: Container(
              margin: const EdgeInsets.only(right: 8),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(10),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(e, style: const TextStyle(fontSize: 22)),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildInputBar() {
    return Container(
      padding: EdgeInsets.fromLTRB(
          12, 10, 12, MediaQuery.of(context).viewInsets.bottom > 0 ? 10 : 20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A2540),
        border: Border(top: BorderSide(color: Colors.white.withAlpha(15))),
      ),
      child: Row(
        children: [
          // Emoji toggle button
          GestureDetector(
            onTap: () {
              HapticService.light();
              _showEmojiBar.value = !_showEmojiBar.value;
              if (_showEmojiBar.value) _focusNode.unfocus();
            },
            child: ValueListenableBuilder<bool>(
              valueListenable: _showEmojiBar,
              builder: (_, show, __) => Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: show
                      ? const Color(0xFF3B82F6).withAlpha(40)
                      : Colors.white.withAlpha(10),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  show ? Icons.keyboard : Icons.emoji_emotions_outlined,
                  color: show ? const Color(0xFF3B82F6) : Colors.white54,
                  size: 20,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          // Text input
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withAlpha(10),
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: Colors.white.withAlpha(15)),
              ),
              child: TextField(
                controller: _msgCtrl,
                focusNode: _focusNode,
                style: const TextStyle(color: Colors.white, fontSize: 15),
                maxLines: 4,
                minLines: 1,
                textCapitalization: TextCapitalization.sentences,
                decoration: const InputDecoration(
                  hintText: 'Share with your community…',
                  hintStyle: TextStyle(color: Colors.white38, fontSize: 15),
                  border: InputBorder.none,
                  contentPadding:
                  EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                ),
                onTap: () => _showEmojiBar.value = false,
                onSubmitted: (_) => _send(),
              ),
            ),
          ),
          const SizedBox(width: 10),
          // Send button
          GestureDetector(
            onTap: _sending ? null : _send,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF3B82F6), Color(0xFF8B5CF6)],
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                      color: const Color(0xFF3B82F6).withAlpha(80),
                      blurRadius: 10,
                      offset: const Offset(0, 4)),
                ],
              ),
              child: _sending
                  ? const Center(
                child: SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2),
                ),
              )
                  : const Icon(Icons.send_rounded, color: Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Message bubble ──────────────────────────────────────────────────────────────

class _MessageBubble extends StatefulWidget {
  final CommunityMessage message;
  final bool isMe;
  final bool showAvatar;
  final String myUid;
  final Function(String emoji) onReact;
  final VoidCallback onDelete;

  const _MessageBubble({
    super.key,
    required this.message,
    required this.isMe,
    required this.showAvatar,
    required this.myUid,
    required this.onReact,
    required this.onDelete,
  });

  @override
  State<_MessageBubble> createState() => _MessageBubbleState();
}

class _MessageBubbleState extends State<_MessageBubble>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  late Animation<double> _scaleAnim;
  bool _isDeleting = false;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 350));
    _scaleAnim = Tween<double>(begin: 1.0, end: 0.0)
        .animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeInBack));
    _animCtrl.forward(from: 1.0); // start at end (no entry animation)
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    super.dispose();
  }

  void _showUserProfile(BuildContext context, CommunityMessage msg) {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A2540),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 20, 24, 36),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle
            Container(width: 36, height: 4,
                decoration: BoxDecoration(color: Colors.white24,
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 24),

            // Avatar
            AvatarWidget(avatarId: msg.avatarId, size: 72),
            const SizedBox(height: 14),

            // Name
            Text(msg.displayName,
                style: const TextStyle(color: Colors.white, fontSize: 20,
                    fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),

            // Stats row
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _StatPill(
                  icon: Icons.self_improvement,
                  label: 'Meditated',
                  value: msg.totalMinutes >= 60
                      ? '${msg.totalMinutes ~/ 60}h ${msg.totalMinutes % 60}m'
                      : '${msg.totalMinutes}m',
                  color: const Color(0xFF8B5CF6),
                ),
              ],
            ),

            // Badges
            if (msg.badges.isNotEmpty) ...[
              const SizedBox(height: 20),
              Align(
                alignment: Alignment.centerLeft,
                child: Text('Achievements',
                    style: TextStyle(color: Colors.white.withAlpha(120),
                        fontSize: 12, fontWeight: FontWeight.w600)),
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8, runSpacing: 8,
                children: msg.badges.map((b) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withAlpha(10),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.white.withAlpha(20)),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(b.emoji, style: const TextStyle(fontSize: 18)),
                    const SizedBox(width: 8),
                    Text(b.title,
                        style: const TextStyle(color: Colors.white70,
                            fontSize: 13, fontWeight: FontWeight.w600)),
                  ]),
                )).toList(),
              ),
            ],

            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  void _showOwnerOptions(BuildContext context) {
    HapticService.medium();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A2540),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Padding(
        padding: const EdgeInsets.fromLTRB(24, 16, 24, 36),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 36, height: 4,
              decoration: BoxDecoration(color: Colors.white24,
                  borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 20),
          // React option
          ListTile(
            leading: const Text('😄', style: TextStyle(fontSize: 22)),
            title: const Text('Add Reaction',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            onTap: () {
              Navigator.pop(context);
              _showReactionPicker(context);
            },
          ),
          const Divider(color: Colors.white12),
          // Delete option
          ListTile(
            leading: const Icon(Icons.delete_outline_rounded,
                color: Color(0xFFEF4444)),
            title: const Text('Delete Message',
                style: TextStyle(color: Color(0xFFEF4444),
                    fontWeight: FontWeight.w600)),
            onTap: () {
              Navigator.pop(context);
              _confirmDelete(context);
            },
          ),
        ]),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A2540),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('Delete message?',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
        content: const Text('Everyone will see "This message was deleted".',
            style: TextStyle(color: Colors.white60, fontSize: 13)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel', style: TextStyle(color: Colors.white54)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Delete', style: TextStyle(color: Color(0xFFEF4444))),
          ),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      setState(() => _isDeleting = true);
      _animCtrl.reverse().then((_) {
        widget.onDelete();
      });
    }
  }

  void _showLongPressMenu(BuildContext context) {
    HapticService.medium();
    if (widget.isMe && !widget.message.isDeleted) {
      showModalBottomSheet(
        context: context,
        backgroundColor: const Color(0xFF1A2540),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
        builder: (_) => Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 36),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 36, height: 4,
                  decoration: BoxDecoration(color: Colors.white24,
                      borderRadius: BorderRadius.circular(2))),
              const SizedBox(height: 20),
              // React option
              ListTile(
                leading: const Text('😊', style: TextStyle(fontSize: 22)),
                title: const Text('Add Reaction',
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                onTap: () {
                  Navigator.pop(context);
                  _showReactionPicker(context);
                },
              ),
              const Divider(color: Colors.white12),
              // Delete option
              ListTile(
                leading: const Icon(Icons.delete_outline_rounded, color: Color(0xFFEF4444)),
                title: const Text('Delete Message',
                    style: TextStyle(color: Color(0xFFEF4444), fontWeight: FontWeight.w600)),
                onTap: () {
                  Navigator.pop(context);
                  _confirmDelete(context);
                },
              ),
            ],
          ),
        ),
      );
    } else {
      _showReactionPicker(context);
    }
  }

  void _showReactionPicker(BuildContext context) {
    HapticService.light();
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1A2540),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                width: 36,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 16),
            const Text('React',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: _CommunityScreenState._reactEmojis.map((e) {
                final count = (widget.message.reactions[e] ?? []).length;
                final reacted = (widget.message.reactions[e] ?? []).contains(widget.myUid);
                return GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    widget.onReact(e);
                  },
                  child: Column(
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: reacted
                              ? const Color(0xFF3B82F6).withAlpha(40)
                              : Colors.white.withAlpha(10),
                          borderRadius: BorderRadius.circular(16),
                          border: reacted
                              ? Border.all(
                              color: const Color(0xFF3B82F6).withAlpha(100))
                              : null,
                        ),
                        child: Text(e, style: const TextStyle(fontSize: 28)),
                      ),
                      if (count > 0) ...[
                        const SizedBox(height: 4),
                        Text('$count',
                            style: TextStyle(
                                color: reacted
                                    ? const Color(0xFF3B82F6)
                                    : Colors.white54,
                                fontSize: 12,
                                fontWeight: FontWeight.w600)),
                      ],
                    ],
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final message = widget.message;
    final isMe = widget.isMe;
    final showAvatar = widget.showAvatar;
    final time = _formatTime(message.timestamp);
    final allReactions = message.reactions.entries
        .where((e) => e.value.isNotEmpty)
        .toList();

    return _isDeleting
        ? SizeTransition(
      sizeFactor: _scaleAnim,
      child: FadeTransition(
        opacity: _scaleAnim,
        child: const SizedBox(height: 48),
      ),
    )
        : GestureDetector(
      onLongPress: () => message.isDeleted ? null : _showLongPressMenu(context),
      child: Padding(
        padding: EdgeInsets.only(
          top: 2,
          bottom: 2,
          left: isMe ? 48 : 0,
          right: isMe ? 0 : 48,
        ),
        child: Row(
          mainAxisAlignment:
          isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            // Other user avatar — tappable
            if (!isMe)
              Padding(
                padding: const EdgeInsets.only(right: 8, bottom: 4),
                child: showAvatar
                    ? GestureDetector(
                  onTap: () => _showUserProfile(context, message),
                  child: AvatarWidget(avatarId: message.avatarId, size: 32),
                )
                    : const SizedBox(width: 32),
              ),

            // Bubble
            Flexible(
              child: Column(
                crossAxisAlignment:
                isMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  // Name + badges — tappable
                  if (!isMe && showAvatar) ...[
                    GestureDetector(
                      onTap: () => _showUserProfile(context, message),
                      child: Padding(
                        padding: const EdgeInsets.only(left: 4, bottom: 4),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(message.displayName,
                                style: const TextStyle(
                                    color: Colors.white60,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600)),
                            ...message.badges.take(3).map((b) => Padding(
                              padding: const EdgeInsets.only(left: 4),
                              child: Tooltip(
                                message: b.title,
                                child: Text(b.emoji,
                                    style: const TextStyle(fontSize: 11)),
                              ),
                            )),
                            if (message.totalMinutes > 0) ...[
                              const SizedBox(width: 5),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                                decoration: BoxDecoration(
                                  color: const Color(0xFF8B5CF6).withAlpha(40),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text('${message.totalMinutes}m',
                                    style: const TextStyle(
                                        color: Color(0xFF8B5CF6),
                                        fontSize: 9,
                                        fontWeight: FontWeight.w700)),
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ],

                  // Bubble content
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: isMe
                          ? const Color(0xFF3B82F6)
                          : const Color(0xFF1E2D4A),
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(18),
                        topRight: const Radius.circular(18),
                        bottomLeft: isMe
                            ? const Radius.circular(18)
                            : const Radius.circular(4),
                        bottomRight: isMe
                            ? const Radius.circular(4)
                            : const Radius.circular(18),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withAlpha(40),
                          blurRadius: 6,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: message.isDeleted
                        ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.block_rounded,
                            size: 13,
                            color: Colors.white.withAlpha(60)),
                        const SizedBox(width: 6),
                        Text('This message was deleted',
                            style: TextStyle(
                                color: Colors.white.withAlpha(60),
                                fontSize: 13,
                                fontStyle: FontStyle.italic)),
                      ],
                    )
                        : _buildMentionText(message.text, isMe),
                  ),

                  // Time
                  Padding(
                    padding: const EdgeInsets.only(top: 3, left: 4, right: 4),
                    child: Text(time,
                        style: const TextStyle(
                            color: Colors.white24, fontSize: 10)),
                  ),

                  // Reaction chips
                  if (allReactions.isNotEmpty && !message.isDeleted)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Wrap(
                        spacing: 4,
                        children: allReactions.map((e) {
                          final count = e.value.length;
                          final iMine = e.value.contains(widget.myUid);
                          return GestureDetector(
                            onTap: () => widget.onReact(e.key),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: iMine
                                    ? const Color(0xFF3B82F6).withAlpha(50)
                                    : Colors.white.withAlpha(12),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: iMine
                                      ? const Color(0xFF3B82F6).withAlpha(120)
                                      : Colors.white.withAlpha(20),
                                ),
                              ),
                              child: Text('${e.key} $count',
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: iMine
                                          ? const Color(0xFF3B82F6)
                                          : Colors.white60)),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMentionText(String text, bool isMe) {
    final baseColor = isMe ? Colors.white : Colors.white.withAlpha(220);
    // Find all @mentions
    final regex = RegExp(r'@\w+');
    final spans = <TextSpan>[];
    int last = 0;
    for (final match in regex.allMatches(text)) {
      if (match.start > last) {
        spans.add(TextSpan(text: text.substring(last, match.start)));
      }
      spans.add(TextSpan(
        text: match.group(0),
        style: TextStyle(
          color: isMe ? Colors.white : const Color(0xFF60A5FA),
          fontWeight: FontWeight.w700,
          backgroundColor: isMe
              ? Colors.white.withAlpha(30)
              : const Color(0xFF3B82F6).withAlpha(30),
        ),
      ));
      last = match.end;
    }
    if (last < text.length) spans.add(TextSpan(text: text.substring(last)));

    return RichText(
      text: TextSpan(
        style: TextStyle(color: baseColor, fontSize: 14, height: 1.4),
        children: spans,
      ),
    );
  }

  String _formatTime(DateTime t) {
    final h = t.hour % 12 == 0 ? 12 : t.hour % 12;
    final m = t.minute.toString().padLeft(2, '0');
    final period = t.hour >= 12 ? 'PM' : 'AM';
    return '$h:$m $period';
  }
}

// ── Date divider ────────────────────────────────────────────────────────────────

class _DateDivider extends StatelessWidget {
  final DateTime date;
  const _DateDivider(this.date);

  String _label() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final d = DateTime(date.year, date.month, date.day);
    if (d == today) return 'Today';
    if (d == today.subtract(const Duration(days: 1))) return 'Yesterday';
    return '${date.day}/${date.month}/${date.year}';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Row(
        children: [
          Expanded(child: Divider(color: Colors.white.withAlpha(15))),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(_label(),
                style: const TextStyle(color: Colors.white30, fontSize: 11)),
          ),
          Expanded(child: Divider(color: Colors.white.withAlpha(15))),
        ],
      ),
    );
  }
}

// ── Stat pill ──────────────────────────────────────────────────────────────────
class _StatPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  const _StatPill({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: color.withAlpha(20),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withAlpha(60)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 8),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(color: color.withAlpha(180), fontSize: 10, fontWeight: FontWeight.w600)),
          Text(value, style: TextStyle(color: color, fontSize: 15, fontWeight: FontWeight.w800)),
        ]),
      ]),
    );
  }
}

// ── User hint model for @mention autocomplete ──────────────────────────────────
class _UserHint {
  final String uid;
  final String name;
  final String? avatarId;
  const _UserHint({required this.uid, required this.name, this.avatarId});
}